using RecipeSystem.Domain.Entities;

namespace RecipeSystem.Application.Common.Interfaces;

public interface IMenuGeneratorService
{
    Task<WeeklyMenu> GenerateAsync(Guid userId, CancellationToken ct = default);
}
