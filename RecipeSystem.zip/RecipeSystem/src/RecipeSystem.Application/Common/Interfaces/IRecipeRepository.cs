using RecipeSystem.Domain.Entities;

namespace RecipeSystem.Application.Common.Interfaces;

public interface IRecipeRepository
{
    Task<IEnumerable<Recipe>> GetAllAsync(CancellationToken ct = default);
    Task<Recipe?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task AddAsync(Recipe recipe, CancellationToken ct = default);
    Task SaveChangesAsync(CancellationToken ct = default);
}

public interface IUserRepository
{
    Task<Domain.Entities.User?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<Domain.Entities.User?> GetWithProfileAsync(Guid id, CancellationToken ct = default);
    Task AddAsync(Domain.Entities.User user, CancellationToken ct = default);
    Task SaveChangesAsync(CancellationToken ct = default);
}

public interface IWeeklyMenuRepository
{
    Task<WeeklyMenu?> GetCurrentForUserAsync(Guid userId, CancellationToken ct = default);
    Task AddAsync(WeeklyMenu menu, CancellationToken ct = default);
    Task SaveChangesAsync(CancellationToken ct = default);
}

public interface ISupplyRepository
{
    Task<IEnumerable<Supply>> GetAllAsync(CancellationToken ct = default);
    Task<Supply?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task AddAsync(Supply supply, CancellationToken ct = default);
    Task SaveChangesAsync(CancellationToken ct = default);
}
