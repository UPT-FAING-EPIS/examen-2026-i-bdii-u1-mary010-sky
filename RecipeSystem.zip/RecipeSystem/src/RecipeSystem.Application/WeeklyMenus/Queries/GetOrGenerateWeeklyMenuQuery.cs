using MediatR;
using RecipeSystem.Application.Common.Interfaces;
using RecipeSystem.Domain.Entities;

namespace RecipeSystem.Application.WeeklyMenus.Queries;

public record GetOrGenerateWeeklyMenuQuery(Guid UserId) : IRequest<WeeklyMenu>;

public class GetOrGenerateWeeklyMenuQueryHandler(
    IWeeklyMenuRepository menuRepo,
    IMenuGeneratorService generator) : IRequestHandler<GetOrGenerateWeeklyMenuQuery, WeeklyMenu>
{
    public async Task<WeeklyMenu> Handle(GetOrGenerateWeeklyMenuQuery request, CancellationToken ct)
    {
        var existing = await menuRepo.GetCurrentForUserAsync(request.UserId, ct);
        if (existing is not null) return existing;

        var menu = await generator.GenerateAsync(request.UserId, ct);
        await menuRepo.AddAsync(menu, ct);
        await menuRepo.SaveChangesAsync(ct);
        return menu;
    }
}
