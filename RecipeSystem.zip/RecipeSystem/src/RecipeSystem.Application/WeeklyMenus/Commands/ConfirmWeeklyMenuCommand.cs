using MediatR;
using RecipeSystem.Application.Common.Interfaces;

namespace RecipeSystem.Application.WeeklyMenus.Commands;

public record ConfirmWeeklyMenuCommand(Guid UserId) : IRequest;

public class ConfirmWeeklyMenuCommandHandler(IWeeklyMenuRepository menuRepo)
    : IRequestHandler<ConfirmWeeklyMenuCommand>
{
    public async Task Handle(ConfirmWeeklyMenuCommand request, CancellationToken ct)
    {
        var menu = await menuRepo.GetCurrentForUserAsync(request.UserId, ct)
            ?? throw new InvalidOperationException("No active menu found.");
        menu.Confirm();
        await menuRepo.SaveChangesAsync(ct);
    }
}
