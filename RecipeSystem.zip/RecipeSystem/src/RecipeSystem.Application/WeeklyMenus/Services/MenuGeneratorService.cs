using RecipeSystem.Application.Common.Interfaces;
using RecipeSystem.Domain.Entities;
using RecipeSystem.Domain.Enums;

namespace RecipeSystem.Application.WeeklyMenus.Services;

public class MenuGeneratorService(IRecipeRepository recipeRepo, IUserRepository userRepo)
    : IMenuGeneratorService
{
    private static readonly string[] MealTypes = ["Breakfast", "Lunch", "Dinner", "Snack"];

    public async Task<WeeklyMenu> GenerateAsync(Guid userId, CancellationToken ct = default)
    {
        var user = await userRepo.GetWithProfileAsync(userId, ct)
            ?? throw new InvalidOperationException($"User {userId} not found.");

        var allRecipes = await recipeRepo.GetAllAsync(ct);
        var safeRecipes = FilterByHealthProfile(allRecipes, user);
        var scored = ScoreByGoal(safeRecipes, user.Goal);

        var menu = WeeklyMenu.Create(userId, GetMonday(DateTime.UtcNow));
        var rng = new Random();

        for (int day = 1; day <= 7; day++)
        {
            foreach (var mealType in MealTypes)
            {
                var candidates = scored
                    .Where(r => r.Recipe.Category.Slug == MapMealToSlug(mealType))
                    .OrderByDescending(r => r.Score)
                    .Take(10)
                    .ToList();

                if (candidates.Count == 0) continue;

                var selected = WeightedRandom(candidates, rng);
                menu.AddDetail(day, mealType, selected.Recipe.Id);
            }
        }

        return menu;
    }

    private static IEnumerable<Recipe> FilterByHealthProfile(IEnumerable<Recipe> recipes, Domain.Entities.User user)
    {
        var allergyNames = user.Allergies.Select(a => a.Allergy.Name.ToLower()).ToHashSet();
        var conditionRules = BuildConditionRules(user.Conditions.Select(c => c.Condition.Name));

        return recipes.Where(r =>
        {
            var hasAllergen = r.RecipeSupplies.Any(rs =>
                allergyNames.Contains(rs.Supply.Name.ToLower()));
            if (hasAllergen) return false;
            return conditionRules.All(rule => rule(r));
        });
    }

    private static List<(Recipe Recipe, double Score)> ScoreByGoal(IEnumerable<Recipe> recipes, GoalType goal)
    {
        return recipes.Select(r =>
        {
            var nutrition = CalculateNutrition(r);
            double score = goal switch
            {
                GoalType.LoseWeight     => -nutrition.Calories * 0.5 + nutrition.Protein * 1.2,
                GoalType.GainMuscle     =>  nutrition.Protein * 2.0 + nutrition.Calories * 0.3,
                GoalType.MaintainWeight =>  100 - Math.Abs(nutrition.Calories - 500),
                _                       =>  nutrition.Protein + nutrition.Calories * 0.1
            };
            return (r, score);
        }).ToList();
    }

    private static IEnumerable<Func<Recipe, bool>> BuildConditionRules(IEnumerable<string> conditions)
    {
        var rules = new List<Func<Recipe, bool>>();
        foreach (var condition in conditions)
        {
            if (condition.Contains("diabetes", StringComparison.OrdinalIgnoreCase))
                rules.Add(r => CalculateNutrition(r).Carbs < 60);
            if (condition.Contains("hipertensión", StringComparison.OrdinalIgnoreCase))
                rules.Add(r => r.RecipeSupplies.All(rs => rs.Supply.Name.ToLower() != "sal"));
        }
        return rules;
    }

    private static (double Calories, double Protein, double Carbs) CalculateNutrition(Recipe r) =>
        r.RecipeSupplies.Aggregate(
            (Calories: 0.0, Protein: 0.0, Carbs: 0.0),
            (acc, rs) => (
                acc.Calories + rs.Supply.CaloriesPer100g * rs.Quantity / 100,
                acc.Protein  + rs.Supply.ProteinPer100g  * rs.Quantity / 100,
                acc.Carbs    + rs.Supply.CarbsPer100g    * rs.Quantity / 100));

    private static (Recipe Recipe, double Score) WeightedRandom(
        List<(Recipe Recipe, double Score)> items, Random rng)
    {
        var total = items.Sum(i => Math.Max(i.Score, 0.1));
        var pick = rng.NextDouble() * total;
        double acc = 0;
        foreach (var item in items)
        {
            acc += Math.Max(item.Score, 0.1);
            if (acc >= pick) return item;
        }
        return items[^1];
    }

    private static string MapMealToSlug(string mealType) => mealType.ToLower() switch
    {
        "breakfast" => "desayuno",
        "lunch"     => "almuerzo",
        "dinner"    => "cena",
        _           => "snack"
    };

    private static DateOnly GetMonday(DateTime date)
    {
        var d = DateOnly.FromDateTime(date);
        int diff = ((int)d.DayOfWeek - 1 + 7) % 7;
        return d.AddDays(-diff);
    }
}
