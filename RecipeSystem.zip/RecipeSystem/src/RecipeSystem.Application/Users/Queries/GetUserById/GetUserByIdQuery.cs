using MediatR;
using RecipeSystem.Application.Common.Interfaces;
using RecipeSystem.Application.Users.DTOs;

namespace RecipeSystem.Application.Users.Queries.GetUserById;

public record GetUserByIdQuery(Guid Id) : IRequest<UserDto?>;

public class GetUserByIdQueryHandler(IUserRepository repo) : IRequestHandler<GetUserByIdQuery, UserDto?>
{
    public async Task<UserDto?> Handle(GetUserByIdQuery request, CancellationToken ct)
    {
        var user = await repo.GetByIdAsync(request.Id, ct);
        if (user is null) return null;
        return new UserDto(user.Id, user.FullName, user.Email, user.Goal.ToString(), user.CreatedAt);
    }
}
