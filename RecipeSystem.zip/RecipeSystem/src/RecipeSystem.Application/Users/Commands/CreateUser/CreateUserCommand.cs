using MediatR;
using RecipeSystem.Application.Common.Interfaces;
using RecipeSystem.Application.Users.DTOs;
using RecipeSystem.Domain.Entities;
using RecipeSystem.Domain.Enums;

namespace RecipeSystem.Application.Users.Commands.CreateUser;

public record CreateUserCommand(
    string FullName,
    string Email,
    string Password,
    DateTime BirthDate,
    string Gender,
    float WeightKg,
    float HeightCm,
    GoalType Goal) : IRequest<UserDto>;

public class CreateUserCommandHandler(IUserRepository repo) : IRequestHandler<CreateUserCommand, UserDto>
{
    public async Task<UserDto> Handle(CreateUserCommand request, CancellationToken ct)
    {
        var passwordHash = BCrypt.Net.BCrypt.HashPassword(request.Password);
        var user = User.Create(request.FullName, request.Email, passwordHash,
            request.BirthDate, request.Gender, request.WeightKg, request.HeightCm, request.Goal);

        await repo.AddAsync(user, ct);
        await repo.SaveChangesAsync(ct);

        return new UserDto(user.Id, user.FullName, user.Email, user.Goal.ToString(), user.CreatedAt);
    }
}
