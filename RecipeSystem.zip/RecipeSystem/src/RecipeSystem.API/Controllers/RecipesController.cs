using MediatR;
using Microsoft.AspNetCore.Mvc;
using RecipeSystem.Application.Users.Queries.GetUserById;

namespace RecipeSystem.API.Controllers;

/// <summary>Gestión de recetas.</summary>
[ApiController]
[Route("api/recipes")]
public class RecipesController(IMediator mediator) : ControllerBase
{
    /// <summary>Obtiene todas las recetas.</summary>
    [HttpGet]
    public IActionResult GetAll() => Ok(new { message = "Lista de recetas - implementar query" });

    /// <summary>Obtiene una receta por ID.</summary>
    [HttpGet("{id:guid}")]
    public IActionResult GetById(Guid id) => Ok(new { message = $"Receta {id}" });
}
