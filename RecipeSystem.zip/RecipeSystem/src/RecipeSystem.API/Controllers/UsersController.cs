using MediatR;
using Microsoft.AspNetCore.Mvc;
using RecipeSystem.Application.Users.Commands.CreateUser;
using RecipeSystem.Application.Users.Queries.GetUserById;
using RecipeSystem.Application.WeeklyMenus.Commands;
using RecipeSystem.Application.WeeklyMenus.Queries;

namespace RecipeSystem.API.Controllers;

/// <summary>Gestión de usuarios y sus menús semanales.</summary>
[ApiController]
[Route("api/users")]
public class UsersController(IMediator mediator) : ControllerBase
{
    /// <summary>Crea un nuevo usuario.</summary>
    [HttpPost]
    public async Task<IActionResult> CreateUser([FromBody] CreateUserCommand cmd)
    {
        var result = await mediator.Send(cmd);
        return CreatedAtAction(nameof(GetUser), new { id = result.Id }, result);
    }

    /// <summary>Obtiene un usuario por ID.</summary>
    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetUser(Guid id)
    {
        var result = await mediator.Send(new GetUserByIdQuery(id));
        return result is null ? NotFound() : Ok(result);
    }

    /// <summary>Obtiene o genera el menú semanal del usuario.</summary>
    [HttpGet("{id:guid}/weekly-menu")]
    public async Task<IActionResult> GetWeeklyMenu(Guid id)
    {
        var result = await mediator.Send(new GetOrGenerateWeeklyMenuQuery(id));
        return Ok(result);
    }

    /// <summary>Confirma el menú semanal del usuario.</summary>
    [HttpPost("{id:guid}/weekly-menu/confirm")]
    public async Task<IActionResult> ConfirmMenu(Guid id)
    {
        await mediator.Send(new ConfirmWeeklyMenuCommand(id));
        return NoContent();
    }
}
