using Microsoft.AspNetCore.Mvc;

namespace RecipeSystem.API.Controllers;

/// <summary>Gestión de insumos/ingredientes.</summary>
[ApiController]
[Route("api/supplies")]
public class SuppliesController : ControllerBase
{
    /// <summary>Obtiene todos los insumos.</summary>
    [HttpGet]
    public IActionResult GetAll() => Ok(new { message = "Lista de insumos - implementar query" });
}
