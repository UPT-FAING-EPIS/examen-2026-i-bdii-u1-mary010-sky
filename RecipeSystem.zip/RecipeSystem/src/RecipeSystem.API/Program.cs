using Microsoft.EntityFrameworkCore;
using RecipeSystem.Infrastructure;
using RecipeSystem.Infrastructure.Data;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "RecipeSystem API", Version = "v1",
        Description = "API para gestión de recetas y menús semanales personalizados" });
    var xml = Path.Combine(AppContext.BaseDirectory, "RecipeSystem.API.xml");
    if (File.Exists(xml)) c.IncludeXmlComments(xml);
});

builder.Services.AddDbContext<AppDbContext>(opt =>
    opt.UseNpgsql(builder.Configuration.GetConnectionString("Default")));

builder.Services.AddMediatR(cfg =>
{
    cfg.RegisterServicesFromAssembly(typeof(RecipeSystem.Application.Users.Commands.CreateUser.CreateUserCommand).Assembly);
});

builder.Services.AddInfrastructureServices();

builder.Services.AddCors(opt =>
    opt.AddDefaultPolicy(p => p.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader()));

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "RecipeSystem API v1"));
    using var scope = app.Services.CreateScope();
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    await db.Database.MigrateAsync();
}

app.UseHttpsRedirection();
app.UseCors();
app.MapControllers();
app.Run();
