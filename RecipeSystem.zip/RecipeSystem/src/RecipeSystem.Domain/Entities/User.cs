using RecipeSystem.Domain.Enums;

namespace RecipeSystem.Domain.Entities;

public class User
{
    public Guid Id { get; private set; }
    public string FullName { get; private set; } = default!;
    public string Email { get; private set; } = default!;
    public string PasswordHash { get; private set; } = default!;
    public DateTime BirthDate { get; private set; }
    public string Gender { get; private set; } = default!;
    public float WeightKg { get; private set; }
    public float HeightCm { get; private set; }
    public GoalType Goal { get; private set; }
    public DateTime CreatedAt { get; private set; }

    public ICollection<UserCondition> Conditions { get; private set; } = [];
    public ICollection<UserAllergy> Allergies { get; private set; } = [];
    public ICollection<WeeklyMenu> WeeklyMenus { get; private set; } = [];

    protected User() { }

    public static User Create(string fullName, string email, string passwordHash,
        DateTime birthDate, string gender, float weightKg, float heightCm, GoalType goal)
    {
        return new User
        {
            Id = Guid.NewGuid(),
            FullName = fullName,
            Email = email,
            PasswordHash = passwordHash,
            BirthDate = birthDate,
            Gender = gender,
            WeightKg = weightKg,
            HeightCm = heightCm,
            Goal = goal,
            CreatedAt = DateTime.UtcNow
        };
    }
}
