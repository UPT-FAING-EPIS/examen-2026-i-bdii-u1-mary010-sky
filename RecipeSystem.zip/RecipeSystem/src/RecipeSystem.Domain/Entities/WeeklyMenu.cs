using RecipeSystem.Domain.Enums;

namespace RecipeSystem.Domain.Entities;

public class WeeklyMenu
{
    public Guid Id { get; private set; }
    public Guid UserId { get; private set; }
    public DateOnly WeekStart { get; private set; }
    public MenuStatus Status { get; private set; }
    public DateTime? ConfirmedAt { get; private set; }
    public DateTime CreatedAt { get; private set; }

    public User User { get; private set; } = default!;
    public ICollection<WeeklyMenuDetail> Details { get; private set; } = [];

    protected WeeklyMenu() { }

    public static WeeklyMenu Create(Guid userId, DateOnly weekStart)
        => new() { Id = Guid.NewGuid(), UserId = userId, WeekStart = weekStart,
                   Status = MenuStatus.Draft, CreatedAt = DateTime.UtcNow };

    public void AddDetail(int dayOfWeek, string mealType, Guid recipeId)
    {
        Details.Add(new WeeklyMenuDetail
        {
            Id = Guid.NewGuid(), WeeklyMenuId = Id,
            DayOfWeek = dayOfWeek, MealType = mealType,
            RecipeId = recipeId, IsReplaced = false
        });
    }

    public void Confirm()
    {
        if (Status != MenuStatus.Draft)
            throw new InvalidOperationException("Only draft menus can be confirmed.");
        Status = MenuStatus.Confirmed;
        ConfirmedAt = DateTime.UtcNow;
    }
}

public class WeeklyMenuDetail
{
    public Guid Id { get; set; }
    public Guid WeeklyMenuId { get; set; }
    public int DayOfWeek { get; set; }
    public string MealType { get; set; } = default!;
    public Guid RecipeId { get; set; }
    public bool IsReplaced { get; set; }
    public WeeklyMenu WeeklyMenu { get; set; } = default!;
    public Recipe Recipe { get; set; } = default!;
}
