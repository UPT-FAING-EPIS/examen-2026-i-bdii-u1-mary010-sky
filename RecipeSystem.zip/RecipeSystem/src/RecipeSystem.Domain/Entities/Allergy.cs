namespace RecipeSystem.Domain.Entities;

public class Allergy
{
    public int Id { get; private set; }
    public string Name { get; private set; } = default!;
    public ICollection<UserAllergy> UserAllergies { get; private set; } = [];
}

public class UserAllergy
{
    public Guid UserId { get; set; }
    public int AllergyId { get; set; }
    public User User { get; set; } = default!;
    public Allergy Allergy { get; set; } = default!;
}
