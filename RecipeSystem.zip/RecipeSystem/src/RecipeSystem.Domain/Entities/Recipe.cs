namespace RecipeSystem.Domain.Entities;

public class Recipe
{
    public Guid Id { get; private set; }
    public string Title { get; private set; } = default!;
    public string Description { get; private set; } = default!;
    public int CategoryId { get; private set; }
    public int PrepMinutes { get; private set; }
    public int Servings { get; private set; }
    public Guid CreatedByUserId { get; private set; }
    public DateTime CreatedAt { get; private set; }

    public Category Category { get; private set; } = default!;
    public ICollection<RecipeSupply> RecipeSupplies { get; private set; } = [];
    public ICollection<RecipeStep> Steps { get; private set; } = [];

    protected Recipe() { }

    public static Recipe Create(string title, string description, int categoryId,
        int prepMinutes, int servings, Guid createdByUserId)
        => new() { Id = Guid.NewGuid(), Title = title, Description = description,
                   CategoryId = categoryId, PrepMinutes = prepMinutes, Servings = servings,
                   CreatedByUserId = createdByUserId, CreatedAt = DateTime.UtcNow };
}

public class RecipeSupply
{
    public Guid RecipeId { get; set; }
    public Guid SupplyId { get; set; }
    public double Quantity { get; set; }
    public Recipe Recipe { get; set; } = default!;
    public Supply Supply { get; set; } = default!;
}

public class RecipeStep
{
    public Guid Id { get; set; }
    public Guid RecipeId { get; set; }
    public int StepNumber { get; set; }
    public string Description { get; set; } = default!;
    public Recipe Recipe { get; set; } = default!;
}
