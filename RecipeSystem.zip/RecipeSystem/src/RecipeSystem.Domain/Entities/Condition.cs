namespace RecipeSystem.Domain.Entities;

public class Condition
{
    public int Id { get; private set; }
    public string Name { get; private set; } = default!;
    public ICollection<UserCondition> UserConditions { get; private set; } = [];
}

public class UserCondition
{
    public Guid UserId { get; set; }
    public int ConditionId { get; set; }
    public User User { get; set; } = default!;
    public Condition Condition { get; set; } = default!;
}
