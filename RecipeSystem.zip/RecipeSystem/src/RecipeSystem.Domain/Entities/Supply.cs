namespace RecipeSystem.Domain.Entities;

public class Supply
{
    public Guid Id { get; private set; }
    public string Name { get; private set; } = default!;
    public string Unit { get; private set; } = default!;
    public double CaloriesPer100g { get; private set; }
    public double ProteinPer100g { get; private set; }
    public double CarbsPer100g { get; private set; }
    public double FatPer100g { get; private set; }
    public ICollection<RecipeSupply> RecipeSupplies { get; private set; } = [];

    protected Supply() { }

    public static Supply Create(string name, string unit, double calories, double protein, double carbs, double fat)
        => new() { Id = Guid.NewGuid(), Name = name, Unit = unit, CaloriesPer100g = calories,
                   ProteinPer100g = protein, CarbsPer100g = carbs, FatPer100g = fat };
}
