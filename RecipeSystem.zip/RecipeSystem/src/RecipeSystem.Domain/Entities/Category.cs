namespace RecipeSystem.Domain.Entities;

public class Category
{
    public int Id { get; private set; }
    public string Name { get; private set; } = default!;
    public string Slug { get; private set; } = default!;
    public ICollection<Recipe> Recipes { get; private set; } = [];
}
