namespace RecipeSystem.Domain.Enums;

public enum GoalType { LoseWeight, MaintainWeight, GainMuscle, HealthyLifestyle }
public enum MenuStatus { Draft, Confirmed, Archived }
