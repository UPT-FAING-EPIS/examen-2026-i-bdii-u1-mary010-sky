using Microsoft.EntityFrameworkCore;
using RecipeSystem.Application.Common.Interfaces;
using RecipeSystem.Domain.Entities;
using RecipeSystem.Domain.Enums;
using RecipeSystem.Infrastructure.Data;

namespace RecipeSystem.Infrastructure.Repositories;

public class WeeklyMenuRepository(AppDbContext db) : IWeeklyMenuRepository
{
    public Task<WeeklyMenu?> GetCurrentForUserAsync(Guid userId, CancellationToken ct = default)
        => db.WeeklyMenus
            .Include(m => m.Details).ThenInclude(d => d.Recipe)
            .Where(m => m.UserId == userId && m.Status != MenuStatus.Archived)
            .OrderByDescending(m => m.WeekStart)
            .FirstOrDefaultAsync(ct);

    public async Task AddAsync(WeeklyMenu menu, CancellationToken ct = default)
        => await db.WeeklyMenus.AddAsync(menu, ct);

    public Task SaveChangesAsync(CancellationToken ct = default)
        => db.SaveChangesAsync(ct);
}
