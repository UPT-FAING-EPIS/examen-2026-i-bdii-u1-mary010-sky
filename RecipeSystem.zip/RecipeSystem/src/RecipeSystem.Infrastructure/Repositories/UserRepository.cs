using Microsoft.EntityFrameworkCore;
using RecipeSystem.Application.Common.Interfaces;
using RecipeSystem.Domain.Entities;
using RecipeSystem.Infrastructure.Data;

namespace RecipeSystem.Infrastructure.Repositories;

public class UserRepository(AppDbContext db) : IUserRepository
{
    public Task<User?> GetByIdAsync(Guid id, CancellationToken ct = default)
        => db.Users.FirstOrDefaultAsync(u => u.Id == id, ct);

    public Task<User?> GetWithProfileAsync(Guid id, CancellationToken ct = default)
        => db.Users
            .Include(u => u.Conditions).ThenInclude(c => c.Condition)
            .Include(u => u.Allergies).ThenInclude(a => a.Allergy)
            .FirstOrDefaultAsync(u => u.Id == id, ct);

    public async Task AddAsync(User user, CancellationToken ct = default)
        => await db.Users.AddAsync(user, ct);

    public Task SaveChangesAsync(CancellationToken ct = default)
        => db.SaveChangesAsync(ct);
}
