using Microsoft.EntityFrameworkCore;
using RecipeSystem.Application.Common.Interfaces;
using RecipeSystem.Domain.Entities;
using RecipeSystem.Infrastructure.Data;

namespace RecipeSystem.Infrastructure.Repositories;

public class RecipeRepository(AppDbContext db) : IRecipeRepository
{
    public Task<IEnumerable<Recipe>> GetAllAsync(CancellationToken ct = default)
        => Task.FromResult<IEnumerable<Recipe>>(
            db.Recipes.Include(r => r.Category)
                      .Include(r => r.RecipeSupplies).ThenInclude(rs => rs.Supply)
                      .AsEnumerable());

    public Task<Recipe?> GetByIdAsync(Guid id, CancellationToken ct = default)
        => db.Recipes.Include(r => r.Category)
                     .Include(r => r.RecipeSupplies).ThenInclude(rs => rs.Supply)
                     .Include(r => r.Steps)
                     .FirstOrDefaultAsync(r => r.Id == id, ct);

    public async Task AddAsync(Recipe recipe, CancellationToken ct = default)
        => await db.Recipes.AddAsync(recipe, ct);

    public Task SaveChangesAsync(CancellationToken ct = default)
        => db.SaveChangesAsync(ct);
}
