using Microsoft.Extensions.DependencyInjection;
using RecipeSystem.Application.Common.Interfaces;
using RecipeSystem.Application.WeeklyMenus.Services;
using RecipeSystem.Infrastructure.Repositories;

namespace RecipeSystem.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructureServices(this IServiceCollection services)
    {
        services.AddScoped<IUserRepository, UserRepository>();
        services.AddScoped<IRecipeRepository, RecipeRepository>();
        services.AddScoped<IWeeklyMenuRepository, WeeklyMenuRepository>();
        services.AddScoped<IMenuGeneratorService, MenuGeneratorService>();
        return services;
    }
}
