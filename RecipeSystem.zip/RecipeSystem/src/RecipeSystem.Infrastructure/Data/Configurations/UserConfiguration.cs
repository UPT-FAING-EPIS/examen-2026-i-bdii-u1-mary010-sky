using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using RecipeSystem.Domain.Entities;

namespace RecipeSystem.Infrastructure.Data.Configurations;

public class UserConfiguration : IEntityTypeConfiguration<User>
{
    public void Configure(EntityTypeBuilder<User> builder)
    {
        builder.HasKey(u => u.Id);
        builder.Property(u => u.Email).HasMaxLength(255).IsRequired();
        builder.HasIndex(u => u.Email).IsUnique();
        builder.Property(u => u.FullName).HasMaxLength(200).IsRequired();
        builder.Property(u => u.Goal).HasConversion<string>();
    }
}

public class UserConditionConfiguration : IEntityTypeConfiguration<UserCondition>
{
    public void Configure(EntityTypeBuilder<UserCondition> builder)
    {
        builder.HasKey(uc => new { uc.UserId, uc.ConditionId });
    }
}

public class UserAllergyConfiguration : IEntityTypeConfiguration<UserAllergy>
{
    public void Configure(EntityTypeBuilder<UserAllergy> builder)
    {
        builder.HasKey(ua => new { ua.UserId, ua.AllergyId });
    }
}

public class RecipeSupplyConfiguration : IEntityTypeConfiguration<RecipeSupply>
{
    public void Configure(EntityTypeBuilder<RecipeSupply> builder)
    {
        builder.HasKey(rs => new { rs.RecipeId, rs.SupplyId });
    }
}

public class WeeklyMenuConfiguration : IEntityTypeConfiguration<WeeklyMenu>
{
    public void Configure(EntityTypeBuilder<WeeklyMenu> builder)
    {
        builder.HasKey(m => m.Id);
        builder.Property(m => m.Status).HasConversion<string>();
    }
}
