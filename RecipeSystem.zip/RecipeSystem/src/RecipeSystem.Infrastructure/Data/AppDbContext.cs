using Microsoft.EntityFrameworkCore;
using RecipeSystem.Domain.Entities;

namespace RecipeSystem.Infrastructure.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Condition> Conditions => Set<Condition>();
    public DbSet<UserCondition> UserConditions => Set<UserCondition>();
    public DbSet<Allergy> Allergies => Set<Allergy>();
    public DbSet<UserAllergy> UserAllergies => Set<UserAllergy>();
    public DbSet<Recipe> Recipes => Set<Recipe>();
    public DbSet<Supply> Supplies => Set<Supply>();
    public DbSet<RecipeSupply> RecipeSupplies => Set<RecipeSupply>();
    public DbSet<RecipeStep> RecipeSteps => Set<RecipeStep>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<WeeklyMenu> WeeklyMenus => Set<WeeklyMenu>();
    public DbSet<WeeklyMenuDetail> WeeklyMenuDetails => Set<WeeklyMenuDetail>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        builder.ApplyConfigurationsFromAssembly(typeof(AppDbContext).Assembly);
        base.OnModelCreating(builder);
    }
}
