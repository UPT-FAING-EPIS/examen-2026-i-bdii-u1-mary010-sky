variable "aws_region"  { default = "us-east-1" }
variable "env"         { default = "prod" }
variable "db_name"     { default = "recipe_db" }
variable "db_user"     {}
variable "db_password" { sensitive = true }
variable "db_connection_string" { sensitive = true }
variable "ecr_repo_url" {}
variable "image_tag"   { default = "latest" }
