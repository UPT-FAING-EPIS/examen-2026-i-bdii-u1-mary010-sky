output "db_endpoint"        { value = aws_db_instance.postgres.endpoint }
output "cf_distribution_id" { value = aws_cloudfront_distribution.frontend.id }
output "cf_domain_name"     { value = aws_cloudfront_distribution.frontend.domain_name }
