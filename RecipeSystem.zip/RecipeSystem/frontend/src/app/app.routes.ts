import { Routes } from '@angular/router';
export const routes: Routes = [
  { path: '', redirectTo: 'weekly-menu', pathMatch: 'full' },
  { path: 'weekly-menu', loadComponent: () => import('./features/weekly-menu/menu-calendar/menu-calendar.component').then(m => m.MenuCalendarComponent) },
  { path: 'recipes', loadChildren: () => import('./features/recipes/recipes.routes').then(m => m.recipesRoutes) },
  { path: 'auth', loadChildren: () => import('./features/auth/auth.routes').then(m => m.authRoutes) }
];
