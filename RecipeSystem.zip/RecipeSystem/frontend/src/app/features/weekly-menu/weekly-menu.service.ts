import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { WeeklyMenu } from '../../shared/models/weekly-menu.model';
@Injectable({ providedIn: 'root' })
export class WeeklyMenuService {
  private readonly http = inject(HttpClient);
  getOrGenerateMenu(userId: string): Observable<WeeklyMenu> { return this.http.get<WeeklyMenu>(`/api/users/${userId}/weekly-menu`); }
  confirmMenu(userId: string): Observable<void> { return this.http.post<void>(`/api/users/${userId}/weekly-menu/confirm`, {}); }
  replaceRecipe(menuId: string, detailId: string, newRecipeId: string): Observable<void> { return this.http.patch<void>(`/api/weekly-menus/${menuId}/details/${detailId}`, { newRecipeId }); }
}
