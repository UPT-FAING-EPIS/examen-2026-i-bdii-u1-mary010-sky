import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { finalize } from 'rxjs';
import { WeeklyMenuService } from '../weekly-menu.service';
import { AuthService } from '../../../core/services/auth.service';
import { WeeklyMenu, WeeklyMenuDetail } from '../../../shared/models/weekly-menu.model';

@Component({
  selector: 'app-menu-calendar',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="calendar-container">
      <div class="calendar-header">
        <h2>Menú de la semana</h2>
        <span class="week-label">{{ weekLabel() }}</span>
        <button class="btn-confirm" [disabled]="menu()?.status === 'Confirmed'" (click)="confirmMenu()">
          ✓ Confirmar menú
        </button>
      </div>
      @if (loading()) { <div class="loading">Generando tu menú personalizado...</div> }
      @if (menu(); as m) {
        <div class="calendar-grid">
          @for (day of days; track day.index) {
            <div class="day-card">
              <div class="day-header">{{ day.label }}</div>
              <div class="meal-slots">
                @for (mealType of mealTypes; track mealType) {
                  <div class="meal-slot">
                    <span class="meal-label">{{ mealType }}</span>
                    @if (getDetail(m, day.index, mealType); as detail) {
                      <div class="recipe-item"><span>{{ detail.recipe.title }}</span><button class="btn-swap" (click)="openReplace(detail)">↔</button></div>
                    } @else { <span class="no-recipe">—</span> }
                  </div>
                }
              </div>
            </div>
          }
        </div>
      }
    </div>
  `,
  styles: [`.calendar-container{padding:24px}.calendar-header{display:flex;align-items:center;gap:16px;margin-bottom:24px;flex-wrap:wrap}.calendar-header h2{margin:0}.week-label{color:#666;font-size:14px}.btn-confirm{padding:8px 20px;background:#2e7d32;color:white;border:none;border-radius:6px;cursor:pointer}.btn-confirm:disabled{opacity:.5;cursor:not-allowed}.calendar-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:16px}.day-card{border:1px solid #e0e0e0;border-radius:8px;overflow:hidden}.day-header{background:#f5f5f5;padding:10px 14px;font-weight:600;font-size:14px}.meal-slots{padding:8px}.meal-slot{padding:6px 0;border-bottom:1px solid #f0f0f0}.meal-slot:last-child{border-bottom:none}.meal-label{font-size:10px;color:#999;text-transform:uppercase;display:block;margin-bottom:2px}.recipe-item{display:flex;justify-content:space-between;align-items:center;font-size:13px}.btn-swap{background:none;border:none;cursor:pointer;color:#1976d2;font-size:16px}.no-recipe{color:#ccc;font-size:13px}.loading{text-align:center;padding:40px;color:#666}`]
})
export class MenuCalendarComponent implements OnInit {
  private readonly menuService = inject(WeeklyMenuService);
  private readonly authService = inject(AuthService);
  menu = signal<WeeklyMenu | null>(null);
  loading = signal(true);
  days = [{index:1,label:'Lunes'},{index:2,label:'Martes'},{index:3,label:'Miércoles'},{index:4,label:'Jueves'},{index:5,label:'Viernes'},{index:6,label:'Sábado'},{index:7,label:'Domingo'}];
  mealTypes = ['Breakfast','Lunch','Dinner','Snack'];
  weekLabel = computed(() => { const m = this.menu(); if (!m) return ''; return `Semana del ${new Date(m.weekStart).toLocaleDateString('es-PE')}`; });
  ngOnInit() { const userId = this.authService.currentUserId(); this.menuService.getOrGenerateMenu(userId).pipe(finalize(() => this.loading.set(false))).subscribe(menu => this.menu.set(menu)); }
  getDetail(menu: WeeklyMenu, day: number, mealType: string): WeeklyMenuDetail | undefined { return menu.details.find(d => d.dayOfWeek === day && d.mealType === mealType); }
  confirmMenu() { this.menuService.confirmMenu(this.authService.currentUserId()).subscribe(() => { this.menu.update(m => m ? {...m, status: 'Confirmed'} : m); }); }
  openReplace(detail: WeeklyMenuDetail) { console.log('Replace:', detail); }
}
