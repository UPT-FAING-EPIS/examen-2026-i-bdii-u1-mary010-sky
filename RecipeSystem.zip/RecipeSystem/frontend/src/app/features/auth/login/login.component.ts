import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
@Component({ selector: 'app-login', standalone: true, imports: [CommonModule], template: `<div style="padding:24px"><h2>Iniciar Sesión</h2></div>` })
export class LoginComponent {}
