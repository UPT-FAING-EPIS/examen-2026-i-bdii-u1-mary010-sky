import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
@Component({ selector: 'app-register', standalone: true, imports: [CommonModule], template: `<div style="padding:24px"><h2>Registro</h2></div>` })
export class RegisterComponent {}
