import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
@Component({ selector: 'app-recipe-list', standalone: true, imports: [CommonModule], template: `<div style="padding:24px"><h2>Recetas</h2></div>` })
export class RecipeListComponent {}
