import { Routes } from '@angular/router';
export const recipesRoutes: Routes = [
  { path: '', loadComponent: () => import('./recipe-list/recipe-list.component').then(m => m.RecipeListComponent) }
];
