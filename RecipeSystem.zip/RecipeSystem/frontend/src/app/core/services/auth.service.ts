import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly _currentUserId = signal<string>('');
  currentUserId = this._currentUserId.asReadonly();
  login(email: string, password: string) { return this.http.post<{ userId: string; token: string }>('/api/auth/login', { email, password }); }
  setCurrentUser(userId: string) { this._currentUserId.set(userId); }
}
