export interface User {
  id: string; fullName: string; email: string;
  goal: 'LoseWeight' | 'MaintainWeight' | 'GainMuscle' | 'HealthyLifestyle';
  createdAt: string;
}
