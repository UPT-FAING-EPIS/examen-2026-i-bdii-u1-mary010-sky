export interface Supply { id: string; name: string; unit: string; caloriesPer100g: number; proteinPer100g: number; carbsPer100g: number; fatPer100g: number; }
