export interface Recipe { id: string; title: string; description: string; categoryId: number; prepMinutes: number; servings: number; createdAt: string; }
export interface RecipeSummary { id: string; title: string; prepMinutes: number; }
