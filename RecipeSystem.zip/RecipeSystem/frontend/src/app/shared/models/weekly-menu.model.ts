import { RecipeSummary } from './recipe.model';
export type MenuStatus = 'Draft' | 'Confirmed' | 'Archived';
export type MealType = 'Breakfast' | 'Lunch' | 'Dinner' | 'Snack';
export interface WeeklyMenuDetail { id: string; dayOfWeek: number; mealType: MealType; recipe: RecipeSummary; isReplaced: boolean; }
export interface WeeklyMenu { id: string; userId: string; weekStart: string; status: MenuStatus; confirmedAt?: string; details: WeeklyMenuDetail[]; }
